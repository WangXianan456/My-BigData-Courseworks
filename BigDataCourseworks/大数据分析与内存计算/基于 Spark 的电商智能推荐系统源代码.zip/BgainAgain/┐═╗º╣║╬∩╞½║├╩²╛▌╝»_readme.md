---
Topic:
    - 电商
,    - 商业

Field:
    - 机器学习/预测
,    - 机器学习/聚类
,    - 机器学习/分类
,    - 时间序列

Ext:
    - .csv

DatasetUsage:
    - 416614

FolderName:
    - /home/mw/input/data9408/
---

## **背景描述**
客户购物偏好数据集提供了有关消费者行为和购买模式的宝贵见解。了解客户偏好和趋势对于企业定制产品、营销策略和整体客户体验至关重要。
本数据集捕捉了广泛的客户属性，包括年龄、性别、购买历史、首选支付方式、购买频率等。分析这些数据可以帮助企业做出明智的决策、优化产品和提高客户满意度。
本数据集包含与客户购物偏好相关的各种特征的 3900 条记录，为企业收集了必要的信息，以加强对客户群的了解。

![Image Name](https://cdn.kesci.com/upload/image/s34pn37s2n.png?imageView2/0/w/540/h/540)

&nbsp;
## **数据说明**

| 字段 | 说明 |
|-|-|
| Customer ID | 客户唯一标识符 |  
| Age | 客户年龄 |
| Gender | 客户性别(男/女) |
| Item Purchased | 客户购买的商品 |
| Category | 购买商品的类别 |
| Purchase Amount (USD) | 购买金额(美元) |
| Location | 购买地点 |
| Size | 购买商品的尺码 |  
| Color | 购买商品的颜色 |
| Season | 购买商品的季节 |
| Review Rating | 客户对购买商品的评分 |
| Subscription Status | 客户是否拥有订阅(是/否)|
| Shipping Type | 客户选择的配送方式 |
| Discount Applied | 是否应用了折扣(是/否) |
| Promo Code Used | 是否使用了优惠码(是/否) |
| Previous Purchases | 客户在该商店的历史购买总数,不包括当前交易 |
| Payment Method | 客户最常用的支付方式 |
| Frequency of Purchases | 客户购买频率(每周、每两周、每月等) |

&nbsp;
## **数据来源**
https://www.kaggle.com/datasets/iamsouravbanerjee/customer-shopping-trends-dataset/data

许可声明：
```
This dataset is a synthetic creation generated using ChatGPT to simulate a realistic customer shopping experience. Its purpose is to provide a platform for beginners and data enthusiasts, allowing them to create, enjoy, practice, and learn from a dataset that mirrors real-world customer shopping behavior. The aim is to foster learning and experimentation in a simulated environment, encouraging a deeper understanding of data analysis and interpretation in the context of consumer preferences and retail scenarios.
```

&nbsp;
## **问题描述**
分析不同客户群体的消费行为差异(按年龄段、性别、地区等划分客户群体)
分析不同类别商品的销售情况,找出畅销商品
分析各季节的销售趋势,确定高峰销售季节
分析优惠活动的效果,如折扣、优惠码的使用情况
分析客户忠诚度,如回购率、评分、购买频率等指标
分析付款方式偏好,优化支付流程
利用历史数据建立商品推荐系统
预测未来销量,进行库存管理和供应链规划