@echo off
setx JAVA_HOME "F:\JDK\jdk82"
setx SPARK_HOME "F:\Hadoop\spark"
setx HADOOP_HOME "F:\Hadoop\hadoop"
setx PYSPARK_PYTHON "python"
setx PATH "%PATH%;%SPARK_HOME%\bin;%HADOOP_HOME%\bin;%SPARK_HOME%\python;%SPARK_HOME%\python\lib"
echo Environment variables have been set.
echo Please restart your terminal for changes to take effect.
pause
