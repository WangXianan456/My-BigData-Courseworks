from pyspark.sql import SparkSession
from pyspark.ml.feature import StringIndexer, VectorAssembler
from pyspark.ml.recommendation import ALS
from pyspark.ml import Pipeline
from pyspark.sql.functions import col, mean as _mean
from pyspark.ml.evaluation import RegressionEvaluator

def create_spark_session():
    return SparkSession.builder \
        .appName("RecommendationSystem") \
        .config("spark.jars.packages", "io.delta:delta-core_2.12:2.1.0") \
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
        .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
        .getOrCreate()

def prepare_data(spark):
    import os
    from pyspark.sql.functions import when

    # 获取当前文件的绝对路径
    current_dir = os.path.dirname(os.path.abspath(__file__))
    base_dir = os.path.dirname(current_dir)
    
    # 读取数据
    df = spark.read.csv(os.path.join(base_dir, "shopping_trends.csv"), header=True, inferSchema=True)
    
    # 数据预处理
    df = df.withColumn("Customer ID", col("Customer ID").cast("string"))
    df = df.drop("Promo Code Used")
    
    # 将购买频率映射为数值
    frequency_mapping = {
        'Weekly': 52, 'Bi-Weekly': 26, 'Monthly': 12,
        'Quarterly': 4, 'Every 3 Months': 4, 'Annually': 1, 'Fortnightly': 26
    }
    mapping_expr = when(col("Frequency of Purchases").isNotNull(), col("Frequency of Purchases"))
    for key, value in frequency_mapping.items():
        mapping_expr = mapping_expr.when(col("Frequency of Purchases") == key, value)
    df = df.withColumn("Frequency of Purchases", mapping_expr.cast("float"))
    
    # 归一化历史购买总数和购买频率
    max_values = df.select(
        _mean("Previous Purchases").alias("max_previous"),
        _mean("Frequency of Purchases").alias("max_frequency")
    ).collect()[0]
    df = df.withColumn("Previous Purchases", col("Previous Purchases") / max_values["max_previous"])
    df = df.withColumn("Frequency of Purchases", col("Frequency of Purchases") / max_values["max_frequency"])
    
    # 将用户ID和商品ID转换为数值型
    customer_indexer = StringIndexer(inputCol="Customer ID", outputCol="customer_index")
    item_indexer = StringIndexer(inputCol="Item Purchased", outputCol="item_index")
    pipeline = Pipeline(stages=[customer_indexer, item_indexer])
    model = pipeline.fit(df)
    indexed_df = model.transform(df)
    
    # 选择需要的列
    training_df = indexed_df.select(
        col("customer_index").cast("int"),
        col("item_index").cast("int"),
        col("Review Rating").cast("float")
    )
    
    return training_df

def train_model(training_df):
    # 配置ALS模型
    als = ALS(
        maxIter=10,
        regParam=0.01,
        userCol="customer_index",
        itemCol="item_index",
        ratingCol="Review Rating",
        coldStartStrategy="drop"
    )
    
    # 训练模型
    model = als.fit(training_df)
    
    return model

def save_model(model, path):
    model.write().overwrite().save(path)

def evaluate_model(model, training_df):
    """
    评估模型性能，使用RMSE作为评估指标
    """
    # 使用训练数据进行预测
    predictions = model.transform(training_df)
    
    # 过滤掉无效预测（可能由于冷启动策略导致）
    predictions = predictions.filter(predictions["prediction"].isNotNull())
    
    # 配置评估器
    evaluator = RegressionEvaluator(
        metricName="rmse",
        labelCol="Review Rating",
        predictionCol="prediction"
    )
    
    # 计算RMSE
    rmse = evaluator.evaluate(predictions)
    return rmse

def main():
    import os
    import logging
    
    # 配置日志
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    
    # 创建Spark会话
    logging.info("创建Spark会话...")
    spark = create_spark_session()
    
    # 获取当前文件的绝对路径
    current_dir = os.path.dirname(os.path.abspath(__file__))
    base_dir = os.path.dirname(current_dir)
    
    # 创建必要的目录
    model_dir = os.path.join(base_dir, "data", "models", "als_model")
    os.makedirs(os.path.dirname(model_dir), exist_ok=True)
    logging.info(f"模型将保存到: {model_dir}")
    
    # 准备数据
    logging.info("开始准备训练数据...")
    training_df = prepare_data(spark)
    logging.info(f"训练数据准备完成，共有 {training_df.count()} 条记录")
    
    # 训练模型
    logging.info("开始训练ALS模型...")
    model = train_model(training_df)
    logging.info("ALS模型训练完成")
    
    # 评估模型
    logging.info("开始评估模型...")
    rmse = evaluate_model(model, training_df)
    logging.info(f"模型评估完成，RMSE: {rmse:.4f}")
    
    # 保存模型
    logging.info("正在保存模型...")
    save_model(model, model_dir)
    logging.info(f"模型已成功保存到: {model_dir}")
    
    spark.stop()
    logging.info("训练完成，Spark会话已关闭")

if __name__ == "__main__":
    main()
