from pyspark.sql import SparkSession, Row
import os

def create_spark_session():
    return SparkSession.builder \
        .appName("ShowPredictions") \
        .config("spark.sql.legacy.allowUntypedScalaUDF", "true") \
        .getOrCreate()

def show_batch_predictions(spark, batch_dir):
    # 读取原始数据以获取映射关系
    df = spark.read.csv("../shopping_trends.csv", header=True)
    from pyspark.ml.feature import StringIndexer
    
    # 创建用户和商品的索引器
    customer_indexer = StringIndexer(inputCol="Customer ID", outputCol="customer_index")
    item_indexer = StringIndexer(inputCol="Item Purchased", outputCol="item_index")
    
    # 获取映射关系
    customer_model = customer_indexer.fit(df)
    item_model = item_indexer.fit(df)
    
    # 创建反向映射字典
    customer_labels = dict(enumerate(customer_model.labels))
    item_labels = dict(enumerate(item_model.labels))
    
    # 读取预测结果
    try:
        predictions_df = spark.read.parquet(batch_dir)
        
        print(f"\n查看批次 {os.path.basename(batch_dir)} 的预测结果:")
        print("\n===== 预测结果示例 =====")
        
        # 使用原生Spark DataFrame操作
        for row in predictions_df.take(5):
            user_id = customer_labels.get(int(row['customer_index']), "未知用户")
            print(f"\n用户 {user_id} 的前5个推荐商品:")
            
            # 处理recommendations数组
            recs = row['recommendations']
            for rec in recs:
                item_id = item_labels.get(int(rec['item_index']), "未知商品")
                rating = float(rec['rating'])
                print(f"- {item_id} (预测评分: {rating:.2f})")
        
        print(f"\n该批次总预测用户数: {predictions_df.count()}")
        
    except Exception as e:
        print(f"处理批次 {os.path.basename(batch_dir)} 时出错: {str(e)}")

def main():
    """主函数"""
    spark = None
    try:
        # 创建Spark会话
        spark = create_spark_session()
        predictions_dir = "../data/processed/predictions"
        
        # 获取最新的3个批次
        batch_dirs = sorted([
            os.path.join(predictions_dir, d) 
            for d in os.listdir(predictions_dir) 
            if os.path.isdir(os.path.join(predictions_dir, d))
        ])[-3:]
        
        for batch_dir in batch_dirs:
            show_batch_predictions(spark, batch_dir)
            
    except Exception as e:
        print(f"程序运行出错: {str(e)}")
    finally:
        if spark:
            spark.stop()

if __name__ == "__main__":
    main()
