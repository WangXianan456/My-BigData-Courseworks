import os
import time
import logging
from datetime import datetime
from pyspark.sql import SparkSession
from pyspark.ml.recommendation import ALSModel
from pyspark.ml.feature import StringIndexer
from pyspark.sql.types import StructType, StructField, StringType
from pyspark.sql.functions import col, expr, from_json, window

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# 定义常量
MODEL_PATH = "../data/models/als_model"
CHECKPOINT_PATH = "../data/checkpoints"
PREDICTIONS_PATH = "../data/processed/predictions"
BATCH_INTERVAL = "10 seconds"

def create_spark_session():
    """创建优化配置的Spark会话"""
    return SparkSession.builder \
        .appName("RecommendationStreamingPredictor") \
        .config("spark.driver.memory", "4g") \
        .config("spark.executor.memory", "4g") \
        .config("spark.sql.shuffle.partitions", "10") \
        .config("spark.streaming.stopGracefullyOnShutdown", "true") \
        .getOrCreate()

def load_model(spark):
    """加载预训练的ALS模型"""
    try:
        model = ALSModel.load(MODEL_PATH)
        logger.info("成功加载ALS模型")
        return model
    except Exception as e:
        logger.error(f"加载模型失败: {str(e)}")
        raise

def process_batch(batch_df, batchId, model):
    """处理每个微批次数据并生成推荐"""
    try:
        batch_start_time = time.time()
        
        # 转换输入数据
        from pyspark.ml.feature import StringIndexer
        
        # 创建和训练StringIndexer
        indexer = StringIndexer(inputCol="Customer ID", outputCol="customer_index")
        indexer_model = indexer.fit(batch_df)
        users_df = indexer_model.transform(batch_df).select("customer_index").distinct()
        
        # 生成推荐
        recommendations = model.recommendForUserSubset(
            users_df.select(col("customer_index").cast("int")),
            numItems=5
        )
        
        # 保存预测结果
        output_path = os.path.join(PREDICTIONS_PATH, f"batch_{batchId}")
        recommendations.write.mode("overwrite").parquet(output_path)
        
        # 记录性能指标
        processing_time = time.time() - batch_start_time
        num_users = users_df.count()
        logger.info(
            f"批次 {batchId} 处理完成: "
            f"处理时间={processing_time:.2f}秒, "
            f"用户数={num_users}"
        )
        
    except Exception as e:
        logger.error(f"处理批次 {batchId} 时发生错误: {str(e)}")
        raise

def main():
    """主函数"""
    try:
        # 创建Spark会话
        spark = create_spark_session()
        logger.info("Spark会话创建成功")
        
        # 加载模型
        model = load_model(spark)
        
        # 定义流式数据schema
        schema = StructType([
            StructField("Customer ID", StringType(), True),
            StructField("timestamp", StringType(), True)
        ])
        
        # 创建流式查询
        streaming_query = spark \
            .readStream \
            .format("rate") \
            .option("rowsPerSecond", 5) \
            .load() \
            .selectExpr(
                "CAST(MOD(value, 3900) + 1 AS STRING) as `Customer ID`",  # 修改为1-3900之间的ID  # 这里限制了用户ID的生成
                "CAST(timestamp AS STRING) as timestamp"
            ) \
            .writeStream \
            .foreachBatch(lambda df, id: process_batch(df, id, model)) \
            .option("checkpointLocation", CHECKPOINT_PATH) \
            .trigger(processingTime=BATCH_INTERVAL) \
            .start()
        
        # 等待查询终止
        streaming_query.awaitTermination()
        
    except KeyboardInterrupt:
        logger.info("收到终止信号,正在优雅关闭...")
        if streaming_query:
            streaming_query.stop()
        spark.stop()
        
    except Exception as e:
        logger.error(f"程序执行过程中发生错误: {str(e)}")
        raise
    finally:
        logger.info("程序结束")

if __name__ == "__main__":
    main()