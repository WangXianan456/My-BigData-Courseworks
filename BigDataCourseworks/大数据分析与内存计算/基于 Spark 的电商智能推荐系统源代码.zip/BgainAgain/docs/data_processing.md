# 数据处理流程详细说明

## 一、数据加载与预处理

### 1. 数据源
- **文件格式**：CSV
- **数据规模**：3900条记录
- **特征数量**：17个字段
- **数据类型**：
  ```
  Customer ID: 字符串
  Age: 整数
  Gender: 字符串(Male/Female)
  Item Purchased: 字符串
  Category: 字符串
  Purchase Amount (USD): 整数
  Location: 字符串
  Size: 字符串
  Color: 字符串
  Season: 字符串
  Review Rating: 浮点数
  Subscription Status: 字符串(Yes/No)
  Shipping Type: 字符串
  Discount Applied: 字符串(Yes/No)
  Previous Purchases: 整数
  Payment Method: 字符串
  Frequency of Purchases: 字符串
  ```

### 2. 数据清洗
1. **空值处理**
   - 检查结果：数据集中无空值
   - 处理方法：不需要特别处理

2. **重复值处理**
   - 检查结果：无重复记录
   - 处理方法：不需要特别处理

3. **异常值处理**
   - Review Rating范围：[2.5, 5.0]
   - Purchase Amount范围：[20, 100]
   - Previous Purchases范围：[1, 50]
   - 处理方法：数据在合理范围内，无需处理

### 3. 特征工程
1. **类型转换**
   ```python
   - Customer ID: 转换为字符串类型
   - Review Rating: 转换为浮点数类型
   - Purchase Amount: 转换为整数类型
   ```

2. **特征编码**
   ```python
   - 用户ID (Customer ID) → customer_index
   - 商品名称 (Item Purchased) → item_index
   ```

3. **数值映射**
   - 购买频率映射：
     ```python
     {
         'Weekly': 52,
         'Bi-Weekly': 26,
         'Monthly': 12,
         'Quarterly': 4,
         'Every 3 Months': 4,
         'Annually': 1,
         'Fortnightly': 26
     }
     ```

4. **特征归一化**
   - Previous Purchases: 除以均值
   - Frequency of Purchases: 除以均值

## 二、数据转换流水线

### 1. 批处理流程
```mermaid
graph LR
    A[CSV数据] --> B[数据加载]
    B --> C[类型转换]
    C --> D[特征编码]
    D --> E[数值映射]
    E --> F[特征归一化]
    F --> G[训练数据集]
```

### 2. 关键处理步骤
1. **数据加载**
   ```python
   df = spark.read.csv("shopping_trends.csv", header=True, inferSchema=True)
   ```

2. **特征选择**
   ```python
   selected_features = [
       "customer_index",      # 用户ID索引
       "item_index",         # 商品ID索引
       "Review Rating"       # 评分作为标签
   ]
   ```

3. **数据分割**
   - 训练集比例：80%
   - 验证集比例：20%
   - 使用随机分割，固定随机种子(42)

## 三、数据质量控制

### 1. 数据验证
- **完整性检查**：确保所有必需字段都存在
- **类型检查**：确保数据类型转换正确
- **范围检查**：确保数值在有效范围内

### 2. 质量指标
1. **基础指标**
   - 记录总数：3900
   - 特征数量：17
   - 缺失值比例：0%

2. **统计指标**
   - Review Rating平均值
   - Purchase Amount分布
   - Previous Purchases分布

### 3. 监控点
1. **数据加载阶段**
   - 文件存在性检查
   - 数据格式验证
   - 字段完整性检查

2. **预处理阶段**
   - 类型转换成功率
   - 特征编码完整性
   - 归一化结果范围

3. **输出阶段**
   - 训练数据维度检查
   - 特征分布验证
   - 数据平衡性检查

## 四、数据流转说明

### 1. 存储格式
- **原始数据**：CSV文件
- **处理后数据**：Parquet格式
- **特征索引**：保存为模型的一部分

### 2. 数据版本控制
- 使用时间戳标记数据版本
- 保存数据处理参数配置
- 记录数据转换日志

### 3. 数据血缘关系
```mermaid
graph TD
    A[原始CSV] --> B[清洗后数据]
    B --> C[特征工程后数据]
    C --> D[训练数据集]
    C --> E[验证数据集]
```

## 五、性能优化

### 1. 计算优化
- 使用Spark DataFrame API
- 优化Shuffle操作
- 合理设置分区数

### 2. 存储优化
- 使用Parquet列式存储
- 合理设置压缩格式
- 优化数据分区策略

### 3. 内存优化
- 及时释放不需要的数据
- 使用缓存加速重复计算
- 监控内存使用情况
